
import { GoogleGenAI, Type } from "@google/genai";
import { MarketingPlan } from './types';

export const generateMarketingContent = async (input: { 
  link?: string; 
  image?: { data: string; mimeType: string };
  price?: string;
  phone?: string;
}): Promise<MarketingPlan & { sources?: string[] }> => {
  // Creating instance inside the function to ensure the latest environment key is used
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
  
  const prompt = `
    Role: Senior Myanmar E-commerce Specialist.
    Input: ${input.link ? 'Product Link: ' + input.link : 'Product Image provided.'}
    Details: Price ${input.price || 'Discuss'}, Phone: ${input.phone || 'DM'}.
    
    Task: Create a high-converting sales package for Myanmar Facebook.
    Focus: Use persuasive Burmese language. Include clear CTA (Call to Action).
    
    Output JSON format:
    - productName: Catchy name
    - postCaption: Persuasive FB caption (AIDA style)
    - hashtags: 5 trending tags
    - postingTimeSuggestion: Best time to post
    - strategyAdvice: One killer selling tip
    - videoScript: Short script for TikTok/Reels
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: { 
        parts: [
          { text: prompt },
          ...(input.image ? [{ inlineData: { data: input.image.data, mimeType: input.image.mimeType } }] : [])
        ] 
      },
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            productName: { type: Type.STRING },
            postCaption: { type: Type.STRING },
            hashtags: { type: Type.ARRAY, items: { type: Type.STRING } },
            postingTimeSuggestion: { type: Type.STRING },
            strategyAdvice: { type: Type.STRING },
            videoScript: { type: Type.STRING }
          },
          required: ["productName", "postCaption", "hashtags", "postingTimeSuggestion", "strategyAdvice", "videoScript"]
        },
        tools: input.link ? [{ googleSearch: {} }] : []
      }
    });

    // Access text property directly as per SDK rules
    const resultText = (response.text || '{}').trim();
    let jsonContent = resultText;
    
    // Robust JSON extraction
    if (!resultText.startsWith('{')) {
      const match = resultText.match(/\{[\s\S]*\}/);
      if (match) jsonContent = match[0];
    }
    
    const plan = JSON.parse(jsonContent);
    const sources: string[] = [];
    
    // Extract search grounding URLs if available
    if (response.candidates?.[0]?.groundingMetadata?.groundingChunks) {
      response.candidates[0].groundingMetadata.groundingChunks.forEach((chunk: any) => {
        if (chunk.web?.uri) {
          sources.push(chunk.web.uri);
        }
      });
    }

    return { ...plan, sources };
  } catch (error) {
    console.error("Marketing Service Error:", error);
    throw new Error("AI စနစ် ခေတ္တ အဆင်မပြေဖြစ်နေပါသည်။");
  }
};

export const generateProductVisual = async (productName: string, sourceImage?: { data: string, mimeType: string }): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
  const prompt = sourceImage 
    ? `Create a high-quality, professional advertising photo for "${productName}" based on the provided image. Studio lighting, cinematic quality.`
    : `Professional high-end studio photography of "${productName}" on a clean, professional background. 4k resolution.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: { 
        parts: [
          ...(sourceImage ? [{ inlineData: { data: sourceImage.data, mimeType: sourceImage.mimeType } }] : []),
          { text: prompt }
        ] 
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1"
        }
      }
    });
    
    // Extract image data from parts
    const candidates = response.candidates;
    if (candidates && candidates.length > 0) {
      for (const part of candidates[0].content.parts) {
        if (part.inlineData) {
          return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
        }
      }
    }
    throw new Error("Image generation failed");
  } catch (error) {
    console.error("Image Error:", error);
    throw error;
  }
};

export const generateLogo = async (brandName: string, style: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: { 
        parts: [{ 
          text: `A professional minimalist logo for brand "${brandName}". Style: ${style}. Vector art style, flat design.` 
        }] 
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1"
        }
      }
    });
    
    const candidates = response.candidates;
    if (candidates && candidates.length > 0) {
      for (const part of candidates[0].content.parts) {
        if (part.inlineData) {
          return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
        }
      }
    }
    throw new Error("Logo generation failed");
  } catch (error) {
    console.error("Logo Error:", error);
    throw error;
  }
};
