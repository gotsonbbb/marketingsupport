
import React, { useState } from 'react';
import { MarketingPlan } from '../types';

const ContentDisplay: React.FC<{ plan: MarketingPlan }> = ({ plan }) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const disclosureText = "\n\n(မှတ်ချက် - ဤလင့်ခ်မှာ Amazon Affiliate Link ဖြစ်ပြီး ဝယ်ယူမှုရှိပါက ကျွန်ုပ်တို့မှ ကော်မရှင် အနည်းငယ် ရရှိနိုင်ပါသည်။)";

  const copy = (text: string, id: string, includeDisclosure: boolean = false) => {
    const finalContent = includeDisclosure ? text + disclosureText : text;
    navigator.clipboard.writeText(finalContent);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <span className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 text-indigo-600 text-[10px] font-black uppercase tracking-widest rounded-full mb-2">
             <span className="w-1 h-1 rounded-full bg-indigo-500"></span>
             AI Generation
          </span>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">{plan.productName}</h2>
        </div>
        <button 
          onClick={() => copy(`${plan.postCaption}\n\n${plan.hashtags.join(' ')}`, 'all', true)} 
          className={`px-6 py-4 ${copiedId === 'all' ? 'bg-emerald-600' : 'bg-slate-900'} text-white font-black rounded-xl text-xs uppercase tracking-widest transition-all shadow-xl active:scale-95 flex items-center gap-2`}
        >
          {copiedId === 'all' ? '✓ COPIED' : '📋 COPY FB POST'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-white rounded-[2rem] shadow-sm border border-slate-100 overflow-hidden">
             <div className="p-4 border-b border-slate-50 flex items-center justify-between bg-slate-50/50">
                <h4 className="font-black text-[11px] text-slate-400 uppercase tracking-widest">Facebook Post Caption</h4>
                <button 
                  onClick={() => copy(plan.postCaption, 'caption')}
                  className={`text-[10px] font-black ${copiedId === 'caption' ? 'text-emerald-600' : 'text-indigo-600'} transition-colors`}
                >
                  {copiedId === 'caption' ? 'Copied' : 'Copy Text'}
                </button>
             </div>
             <div className="p-8">
                <p className="whitespace-pre-line text-slate-700 font-medium leading-[1.8] mb-8 text-[15px]">{plan.postCaption}</p>
                <div className="flex flex-wrap gap-2 pt-4 border-t border-slate-50 mb-6">
                  {plan.hashtags.map((h, i) => (
                    <span key={i} className="text-[10px] font-bold text-indigo-500 bg-indigo-50/50 px-3 py-1.5 rounded-lg">
                      {h}
                    </span>
                  ))}
                </div>
                {plan.sources && plan.sources.length > 0 && (
                  <div className="pt-6 border-t border-slate-50">
                    <h5 className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-3">Grounding Info</h5>
                    <div className="flex flex-col gap-2">
                      {plan.sources.map((s, idx) => (
                        <a key={idx} href={s} target="_blank" rel="noopener" className="text-[10px] text-indigo-400 hover:underline truncate font-bold">🔗 {s}</a>
                      ))}
                    </div>
                  </div>
                )}
             </div>
          </div>

          <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm flex items-center gap-4">
             <div className="w-12 h-12 bg-amber-50 rounded-xl flex items-center justify-center text-amber-500 text-2xl">⏰</div>
             <div>
                <h4 className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Best Posting Time</h4>
                <p className="text-slate-900 font-black text-sm">{plan.postingTimeSuggestion}</p>
             </div>
          </div>
        </div>

        <div className="lg:col-span-4 space-y-6">
          <div className="bg-slate-900 text-white p-8 rounded-[2rem] shadow-xl">
             <h4 className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-4">AI Selling Advice</h4>
             <p className="text-slate-300 text-sm font-medium leading-relaxed italic">
               "{plan.strategyAdvice}"
             </p>
          </div>

          <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm">
             <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Short Video Concept</h4>
             <div className="bg-slate-50 p-4 rounded-xl">
                <p className="text-slate-600 text-[11px] font-mono leading-[1.8] whitespace-pre-line">{plan.videoScript}</p>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContentDisplay;
