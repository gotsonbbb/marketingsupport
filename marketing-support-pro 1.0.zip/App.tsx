
import React, { useState, useEffect } from 'react';
import ProductForm from './components/ProductForm';
import ContentDisplay from './components/ContentDisplay';
import ImageGenerator from './components/ImageGenerator';
import LogoGenerator from './components/LogoGenerator';
import HistoryList from './components/HistoryList';
import ActivityLog from './components/ActivityLog';
import GmailSettings from './components/GmailSettings';
import { MarketingPlan, LoadingState, HistoryItem } from './types';
import { generateMarketingContent } from './geminiService';

const App: React.FC = () => {
  const [marketingPlan, setMarketingPlan] = useState<MarketingPlan | null>(null);
  const [loadingState, setLoadingState] = useState<LoadingState>(LoadingState.IDLE);
  const [imageUrl, setImageUrl] = useState<string | undefined>();
  const [sourceImage, setSourceImage] = useState<{ data: string; mimeType: string } | undefined>();
  const [logs, setLogs] = useState<string[]>([]);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isGmailOpen, setIsGmailOpen] = useState(false);

  useEffect(() => {
    try {
      const saved = localStorage.getItem('marketing_app_history');
      if (saved) setHistory(JSON.parse(saved));
    } catch (e) {
      console.error("History recovery failed", e);
    }
    addLog("🚀 Marketing System Ready.");
  }, []);

  const addLog = (msg: string) => setLogs(p => [`${new Date().toLocaleTimeString()} - ${msg}`, ...p.slice(0, 15)]);

  const handleFormSubmit = async (input: { link?: string; image?: { data: string; mimeType: string }; price?: string; phone?: string; }) => {
    setLoadingState(LoadingState.ANALYZING);
    setMarketingPlan(null);
    setImageUrl(undefined);
    setSourceImage(input.image);
    addLog(`🔍 Processing product info...`);

    try {
      const plan = await generateMarketingContent(input);
      setMarketingPlan(plan);
      addLog("✅ Content generation complete.");
      
      const newItem: HistoryItem = {
        id: Date.now().toString(),
        timestamp: Date.now(),
        productName: plan.productName,
        productLink: input.link || '',
        plan,
        status: 'APPROVED'
      };
      
      const updatedHistory = [newItem, ...history.slice(0, 20)];
      setHistory(updatedHistory);
      localStorage.setItem('marketing_app_history', JSON.stringify(updatedHistory));
      setLoadingState(LoadingState.COMPLETE);
    } catch (error: any) {
      setLoadingState(LoadingState.ERROR);
      addLog(`❌ Error: ${error.message}`);
    }
  };

  const handleHistorySelect = (item: HistoryItem) => {
    setMarketingPlan(item.plan);
    setImageUrl(item.imageUrl);
    setSourceImage(undefined);
    setIsHistoryOpen(false);
    addLog(`📂 Opened: ${item.productName}`);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen pb-12 bg-slate-50/50">
      <header className="sticky top-0 z-[100] bg-white/80 backdrop-blur-xl border-b border-slate-200/60 px-6 py-4 shadow-sm">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => window.scrollTo({top:0, behavior:'smooth'})}>
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg active:scale-95 transition-all">
               <span className="text-lg font-black">M</span>
            </div>
            <div className="hidden sm:block">
              <h1 className="text-md font-extrabold text-slate-900 leading-none">Marketing Pro</h1>
              <span className="text-[9px] font-bold text-indigo-500 uppercase tracking-widest mt-1 inline-block">Enterprise Edition</span>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setIsGmailOpen(true)}
              className="w-10 h-10 flex items-center justify-center bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-all active:scale-95 shadow-sm"
            >
              ⚙️
            </button>
            <button 
              onClick={() => setIsHistoryOpen(true)}
              className="px-5 py-2.5 bg-slate-900 text-white rounded-xl shadow-xl hover:bg-indigo-600 transition-all active:scale-95 text-xs font-black uppercase tracking-wider flex items-center gap-2"
            >
              <span>History</span>
              <span className="bg-white/20 px-1.5 rounded-md text-[10px]">{history.length}</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        <aside className="lg:col-span-4 space-y-6">
          <section className="bg-slate-900 rounded-[2.5rem] p-8 shadow-2xl border border-white/5">
            <ProductForm onSubmit={handleFormSubmit} isLoading={loadingState === LoadingState.ANALYZING} />
          </section>
          
          <LogoGenerator />
          <ActivityLog logs={logs} />
        </aside>

        <section className="lg:col-span-8">
          {marketingPlan ? (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <ContentDisplay plan={marketingPlan} />
              <ImageGenerator 
                productName={marketingPlan.productName} 
                initialImageUrl={imageUrl}
                sourceImage={sourceImage}
                onImageGenerated={(url) => {
                  setImageUrl(url);
                  const updated = history.map(h => 
                    h.id === history[0].id ? { ...h, imageUrl: url } : h
                  );
                  setHistory(updated);
                  localStorage.setItem('marketing_app_history', JSON.stringify(updated));
                }}
              />
            </div>
          ) : (
            <div className="h-[600px] flex flex-col items-center justify-center text-center p-12 bg-white rounded-[2.5rem] border border-slate-100 shadow-sm">
               <div className="w-24 h-24 bg-slate-50 rounded-[2.5rem] flex items-center justify-center text-5xl mb-8 animate-float shadow-inner">
                  🚀
               </div>
               <h2 className="text-3xl font-black text-slate-900 mb-4 tracking-tight">ရောင်းအားတက်ဖို့ အဆင်သင့်ပဲလား?</h2>
               <p className="text-slate-400 font-medium max-w-sm mx-auto text-sm leading-relaxed mb-10">
                 Product Link သို့မဟုတ် ပုံတင်လိုက်ပါ။ ကျန်တာကို AI က တာဝန်ယူပေးပါလိမ့်မယ်။
               </p>
               <div className="flex gap-3">
                 <span className="px-4 py-2 bg-slate-100 rounded-xl text-[10px] font-black text-slate-500 uppercase tracking-widest">Auto SEO</span>
                 <span className="px-4 py-2 bg-slate-100 rounded-xl text-[10px] font-black text-slate-500 uppercase tracking-widest">FB Optimized</span>
               </div>
            </div>
          )}
        </section>
      </main>

      {isHistoryOpen && (
        <div className="fixed inset-0 z-[200] flex justify-end">
          <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={() => setIsHistoryOpen(false)}></div>
          <div className="relative w-full max-w-md bg-white h-full shadow-2xl p-8 flex flex-col animate-in slide-in-from-right duration-300">
             <div className="flex justify-between items-center mb-8">
                <div>
                  <h3 className="text-2xl font-black text-slate-900">Task History</h3>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Cloud Saved Records</p>
                </div>
                <button onClick={() => setIsHistoryOpen(false)} className="w-12 h-12 flex items-center justify-center hover:bg-slate-100 rounded-2xl transition-colors">✕</button>
             </div>
             <div className="flex-1 overflow-y-auto custom-scrollbar">
               <HistoryList 
                 history={history} 
                 onSelectItem={handleHistorySelect} 
                 onClear={() => {
                   if(confirm('မှတ်တမ်းအားလုံးကို ဖျက်လိုပါသလား?')) {
                     setHistory([]);
                     localStorage.removeItem('marketing_app_history');
                   }
                 }} 
               />
             </div>
          </div>
        </div>
      )}

      {isGmailOpen && (
        <GmailSettings onEmailChange={() => {}} onClose={() => setIsGmailOpen(false)} />
      )}
    </div>
  );
};

export default App;
